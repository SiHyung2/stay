package com.example.domain;

public class BoByAcDTO {
	private String email_id;
	public int ac_id;
}
