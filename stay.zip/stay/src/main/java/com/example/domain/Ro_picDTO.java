package com.example.domain;

import lombok.Data;

@Data
public class Ro_picDTO {

	
	private int pic_num;
	private int room_num;
	private String pic_name;
	
}
