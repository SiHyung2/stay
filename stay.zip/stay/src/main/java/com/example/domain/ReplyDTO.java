package com.example.domain;

import lombok.Data;

@Data
public class ReplyDTO {


	private String reply_Content;
	private long reply_Num;
	private long rev_Num;
}