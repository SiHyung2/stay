//package com.example.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.domain.ReplyDTO;
//import com.example.mapper.ReplyMapperTest;
//
//@Service
//public class ReplyServiceTest {
//
//    private final ReplyMapperTest replyMapper;
//
//    @Autowired
//    public ReplyServiceTest(ReplyMapperTest replyMapper) {
//        this.replyMapper = replyMapper;
//    }
//
//    public void addReply(ReplyDTO replyDTO) {
//        replyMapper.addReply(replyDTO);
//    }
//}
//