//import static org.junit.Assert.assertEquals;
//
//import org.junit.Test;
//
//import com.example.domain.ReplyDTO;
//
//public class ReplyMapperTest {
//
//   
//    private ReplyMapper replyMapper;
//
// 
//
// 
