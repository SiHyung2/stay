package com.example.domain;

public class PaymentDTO {

}
